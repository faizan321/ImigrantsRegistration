package com.hisdu.meas.ui.Feedback

data class ImagesModel(

    var title: String?,
    var id: Int?,
    var imageName:String,
    var image:String,
    var editable:Boolean,
    var createdOn:String
)