package com.hisdu.meas.ui.Indicators

enum class OptionType {
    Radiobutton,
    Textbox,
    MultiSelection,
    Label,
    DateTime,
    Image,
    Heading,
    Empty
}