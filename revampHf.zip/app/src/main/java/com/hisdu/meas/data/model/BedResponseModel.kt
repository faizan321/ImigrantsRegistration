package com.hisdu.meas.data.model

data class BedResponseModel(
    val Msg: String,
    val err: String
)