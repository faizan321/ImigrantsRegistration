package com.hisdu.meas.data.model

data class AlreadyExisitHF(
    val AlreadyExist: AlreadyExist,
    val Err: String,
    val Msg: String
)