package com.hisdu.meas.ui.Feedback

import android.widget.ImageView


interface ImageClickListener {

    fun onImageClick(id:Int,imageview: ImageView)

}
