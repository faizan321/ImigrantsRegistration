package com.hisdu.meas.ui.roles

import com.hisdu.meas.ui.Indicators.SubmitFormModel


interface InProcessClickListener {

    fun onClick(recipe: SubmitFormModel)

}
