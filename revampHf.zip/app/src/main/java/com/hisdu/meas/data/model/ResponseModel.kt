package com.hisdu.meas.data.model

data class ResponseModel(
    val Msg: String,
//    val Status: Boolean,

    val StatusCode: Int,

    val err: String
)