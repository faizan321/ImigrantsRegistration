package com.hisdu.meas.data.model

data class WheelChairResponseModel(
    val Msg: String,
    val err: String
)