package com.hisdu.meas.ui.revamp

import android.widget.ImageView


interface BHUImageClickListener {

    fun onBHUImageClick(model:ImagesResponseModel.BHUImageModel, imageView: ImageView)

}
