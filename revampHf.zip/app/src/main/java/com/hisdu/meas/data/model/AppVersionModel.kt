package com.hisdu.meas.data.model


import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AppVersionModel(
    @Json(name = "Error")
    var error: Boolean? = false,
    @Json(name = "List")
    var list: AppVersion,
    @Json(name = "Message")
    var message: String? = "",
    @Json(name = "StatusCode")
    var statusCode: Int? = 0
) {
    @JsonClass(generateAdapter = true)
    data class AppVersion(
        @Json(name = "AppVersionID")
        var appVersionID: String? = "",
        @Json(name = "ChecklistMACS")
        var checklistMACS: String? = "",
        @Json(name = "ChecklistPrimary")
        var checklistPrimary: String? = "",
        @Json(name = "ChecklistSceondary")
        var checklistSceondary:String? = "",
        @Json(name = "Version")
        var version: String? = ""
    )
}