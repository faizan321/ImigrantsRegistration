package com.hisdu.meas.ui.revamp

import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hisdu.meas.databinding.FacilityItemBinding
import com.hisdu.meas.databinding.StaffListItemBinding
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.properties.Delegates

internal class FacilitiesAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    var recipes: List<FacilitesResponseModel.Facility>? by Delegates.observable(emptyList()) { property, oldValue, newValue ->
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val holderRecipeBinding = FacilityItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecipeViewHolder(holderRecipeBinding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as RecipeViewHolder).onBind(getItem(position))
    }

    private fun getItem(position: Int): FacilitesResponseModel.Facility = recipes?.get(position)!!


    override fun getItemCount(): Int = recipes?.size!!


    inner class RecipeViewHolder(private val binding: FacilityItemBinding) : RecyclerView.ViewHolder(binding.root) {

        fun onBind(item: FacilitesResponseModel.Facility) {

            binding.facilityName.text=item.healthfacility
            binding.status.text=item.InspectionStatus

            try {
                // Define the input date format
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")

                    // Parse the input date string into a LocalDateTime object
                    val localDateTime = LocalDateTime.parse(item.InspectionDate, inputFormatter)

                    // Extract the LocalDate part from LocalDateTime
                    val localDate = localDateTime.toLocalDate()

                    // Define the output date format
                    val outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

                    // Convert the LocalDate to the desired string format
                    val outputDateString = localDate.format(outputFormatter)
                    binding.visitDate.text=outputDateString
                }else{
                    binding.visitDate.text=item.InspectionDate
                }

            }
            catch (e:Exception){

            }

        }
    }
}
