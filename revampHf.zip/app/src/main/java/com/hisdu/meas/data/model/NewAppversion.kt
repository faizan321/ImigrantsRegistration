package com.hisdu.meas.data.model

data class NewAppversion(
    val err: String,
    val res: String
)