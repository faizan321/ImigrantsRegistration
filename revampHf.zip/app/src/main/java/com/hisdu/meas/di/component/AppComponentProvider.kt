package com.hisdu.meas.di.component

interface AppComponentProvider {

    fun provideAppComponent(): AppComponent
}