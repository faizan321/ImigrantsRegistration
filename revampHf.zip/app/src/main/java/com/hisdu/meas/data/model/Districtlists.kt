package com.hisdu.meas.data.model

data class Districtlists(
    val Code: String,
    val Name: String
)