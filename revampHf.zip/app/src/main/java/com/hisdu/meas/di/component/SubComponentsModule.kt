package com.hisdu.meas.di.component

import dagger.Module


@Module(subcomponents = [MainComponent::class])
class SubComponentsModule {}