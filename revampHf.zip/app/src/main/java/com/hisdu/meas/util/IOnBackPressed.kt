package com.hisdu.meas.util

interface IOnBackPressed {
    fun onBackPressed(): Boolean

}