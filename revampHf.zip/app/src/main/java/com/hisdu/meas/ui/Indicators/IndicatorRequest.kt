package com.zest.android.ui.login

data class IndicatorRequest(
    var ApplicationType:Int?=null,
    var ModuleId: Int?=null
)

//{
//    constructor() : this(null,null
//    )
//}