package com.hisdu.meas.util.MultiSelectionSpinner;
import java.util.List;

public interface MultiSpinnerListener {
    void onItemsSelected(List<KeyPairBoolData> selectedItems);
}
