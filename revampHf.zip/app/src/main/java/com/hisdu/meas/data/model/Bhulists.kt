package com.hisdu.meas.data.model

data class Bhulists(
    val Code: String,
    val Id: Int,
    val Name: String
)