package com.hisdu.meas.ui.roles


interface RoleClickListener {


}
